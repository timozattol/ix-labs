#!/bin/sh

python plot3d.py features.csv movie_titles.txt
